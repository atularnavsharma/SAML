package in.samlclient.servlet;

import java.io.IOException;
import java.security.Provider;
import java.security.Security;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.joda.time.DateTime;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLObject;
import org.opensaml.common.binding.BasicSAMLMessageContext;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.binding.encoding.HTTPRedirectDeflateEncoder;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnContextComparisonTypeEnumeration;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameIDPolicy;
import org.opensaml.saml2.core.NameIDType;
import org.opensaml.saml2.core.RequestedAuthnContext;
import org.opensaml.saml2.metadata.Endpoint;
import org.opensaml.saml2.metadata.SingleSignOnService;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.opensaml.ws.transport.http.HttpServletResponseAdapter;
import org.opensaml.xml.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import in.samlclient.Credentials;
import in.samlclient.SAMLUtils;

public class AccessFilter implements Filter {

	private static Logger logger = LoggerFactory.getLogger(AccessFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		Configuration.validateJCEProviders();
		Configuration.validateNonSunJAXP();

		for (Provider jceProvider : Security.getProviders()) {
			logger.info(jceProvider.getInfo());
		}

		try {
			logger.info("Bootstrapping");
			DefaultBootstrap.bootstrap();
		} catch (ConfigurationException e) {
			throw new RuntimeException("Bootstrapping failed");
		}
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;

		if (httpServletRequest.getSession().getAttribute("authenticated") != null) {
			chain.doFilter(request, response);
		} else {
			setGotoURLOnSession(httpServletRequest);
			redirectUserForAuthentication(httpServletResponse);
		}
	}

	private void setGotoURLOnSession(HttpServletRequest request) {
		request.getSession().setAttribute("gotoURL", request.getRequestURL().toString());
	}

	private void redirectUserForAuthentication(HttpServletResponse httpServletResponse) {
		AuthnRequest authnRequest = buildAuthnRequest();
		redirectUserWithRequest(httpServletResponse, authnRequest);

	}

	private void redirectUserWithRequest(HttpServletResponse httpServletResponse, AuthnRequest authnRequest) {
		HttpServletResponseAdapter responseAdapter = new HttpServletResponseAdapter(httpServletResponse, true);
		BasicSAMLMessageContext<SAMLObject, AuthnRequest, SAMLObject> context = new BasicSAMLMessageContext<SAMLObject, AuthnRequest, SAMLObject>();
		context.setPeerEntityEndpoint(getIPDEndpoint());
		context.setOutboundSAMLMessage(authnRequest);
		context.setOutboundMessageTransport(responseAdapter);
		context.setOutboundSAMLMessageSigningCredential(Credentials.getCredential());

		HTTPRedirectDeflateEncoder encoder = new HTTPRedirectDeflateEncoder();
		logger.info("AuthnRequest: ");
		SAMLUtils.logSAMLObject(authnRequest);

		logger.info("Redirecting to IDP");
		try {
			encoder.encode(context);
		} catch (MessageEncodingException e) {
			throw new RuntimeException(e);
		}
	}

	private AuthnRequest buildAuthnRequest() {
		AuthnRequest authnRequest = SAMLUtils.buildSAMLObject(AuthnRequest.class);
		authnRequest.setIssueInstant(new DateTime());
		authnRequest.setDestination(getIPDSSODestination());
		authnRequest.setProtocolBinding(SAMLConstants.SAML2_ARTIFACT_BINDING_URI);
		authnRequest.setAssertionConsumerServiceURL(getAssertionConsumerEndpoint());
		authnRequest.setID(SAMLUtils.generateSecureRandomId());
		authnRequest.setIssuer(buildIssuer());
		authnRequest.setNameIDPolicy(buildNameIdPolicy());
		authnRequest.setRequestedAuthnContext(buildRequestedAuthnContext());

		return authnRequest;
	}

	private RequestedAuthnContext buildRequestedAuthnContext() {
		RequestedAuthnContext requestedAuthnContext = SAMLUtils.buildSAMLObject(RequestedAuthnContext.class);
		requestedAuthnContext.setComparison(AuthnContextComparisonTypeEnumeration.MINIMUM);

		AuthnContextClassRef passwordAuthnContextClassRef = SAMLUtils.buildSAMLObject(AuthnContextClassRef.class);
		passwordAuthnContextClassRef.setAuthnContextClassRef(AuthnContext.PASSWORD_AUTHN_CTX);

		requestedAuthnContext.getAuthnContextClassRefs().add(passwordAuthnContextClassRef);

		return requestedAuthnContext;

	}

	private NameIDPolicy buildNameIdPolicy() {
		NameIDPolicy nameIDPolicy = SAMLUtils.buildSAMLObject(NameIDPolicy.class);
		nameIDPolicy.setAllowCreate(true);

		nameIDPolicy.setFormat(NameIDType.TRANSIENT);

		return nameIDPolicy;
	}

	private Issuer buildIssuer() {
		Issuer issuer = SAMLUtils.buildSAMLObject(Issuer.class);
		issuer.setValue(getSPIssuerValue());

		return issuer;
	}

	private String getSPIssuerValue() {
		return "TestSP";
	}

	@SuppressWarnings("unused")
	private String getSPNameQualifier() {
		return "TestSP";
	}

	private String getAssertionConsumerEndpoint() {
		return "http://localhost:8080/TestSP/SPServlet";

	}

	private String getIPDSSODestination() {
		return "http://localhost:8080/TestIdP/SSOServlet";
	}

	private Endpoint getIPDEndpoint() {
		SingleSignOnService endpoint = SAMLUtils.buildSAMLObject(SingleSignOnService.class);
		// SAML Binding
		endpoint.setBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
		endpoint.setLocation(getIPDSSODestination());

		return endpoint;
	}

	public void destroy() {

	}

}
