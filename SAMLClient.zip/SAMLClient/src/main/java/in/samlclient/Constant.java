package in.samlclient;

public class Constant {
	public static final String SP_ENTITY_ID = "TestSP";
	public static final String GOTO_URL_SESSION_ATTRIBUTE = "gotoURL";
	public static final String ASSERTION_CONSUMER_SERVICE = "http://localhost:8080/TestSP/ClientServlet";
	public static final String AUTHENTICATED_SESSION_ATTRIBUTE = "authenticated";

	// IDP path where SAML Assertions Completed
	public static final String ARTIFACT_RESOLUTION_SERVICE = "http://localhost:8080/webprofile-ref-project/idp/artifactResolutionService";

}
