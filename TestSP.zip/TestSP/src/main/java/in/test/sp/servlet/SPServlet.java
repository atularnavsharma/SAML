package in.test.sp.servlet;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.opensaml.saml2.core.Artifact;
import org.opensaml.saml2.core.ArtifactResolve;
import org.opensaml.saml2.core.ArtifactResponse;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.EncryptedAssertion;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import in.test.sp.utilities.SAMLUtils;
import no.steras.opensamlbook.OpenSAMLUtils;

/**
 * Servlet implementation class SPServlet
 */

@WebServlet("/SPServlet")
public class SPServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(SPServlet.class);

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		System.out.println("step 1");
		logger.info("Artifact received");
		Artifact artifact = buildArtifactFromRequest(req);
		logger.info("Artifact: " + artifact.getArtifact());

		ArtifactResolve artifactResolve = buildArtifactResolve(artifact);
		signArtifactResolve(artifactResolve);
		logger.info("Sending ArtifactResolve");
		logger.info("ArtifactResolve: ");
		OpenSAMLUtils.logSAMLObject(artifactResolve);

		ArtifactResponse artifactResponse = sendAndReceiveArtifactResolve(artifactResolve);
		logger.info("ArtifactResponse received");
		logger.info("ArtifactResponse: ");
		OpenSAMLUtils.logSAMLObject(artifactResponse);

		EncryptedAssertion encryptedAssertion = getEncryptedAssertion(artifactResponse);
		Assertion assertion = decryptAssertion(encryptedAssertion);
		verifyAssertionSignature(assertion);
		logger.info("Decrypted Assertion: ");
		OpenSAMLUtils.logSAMLObject(assertion);

		logAssertionAttributes(assertion);
		logAuthenticationInstant(assertion);
		logAuthenticationMethod(assertion);

		setAuthenticatedSession(req);
		redirectToGotoURL(req, resp);
	}

	// getting artifact and setting this to artifact
	 private Artifact buildArtifactFromRequest(final HttpServletRequest req) {
	        Artifact artifact = SAMLUtils.buildSAMLObject(Artifact.class);
	        artifact.setArtifact(req.getParameter("SAMLart"));
	        return artifact;
	    }

}
