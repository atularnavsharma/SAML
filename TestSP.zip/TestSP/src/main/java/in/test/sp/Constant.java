package in.test.sp;

public class Constant {
	public static final String SP_ENTITY_ID = "TestSP";
	public static final String AUTHENTICATED_SESSION_ATTRIBUTE = "authenticated";
	public static final String GOTO_URL_SESSION_ATTRIBUTE = "gotoURL";
	public static final String ASSERTION_CONSUMER_SERVICE = "http://localhost:8080/TestSP/SPServlet";

}
